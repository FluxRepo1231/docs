First Before Anything You need to create a account 

<ol>
  <li>Head Over to Our Panel https://panel.flarebytes.xyz
  <li>Click on the "Dont Have A  Account Register" Button 
  <li>Enter in the details You like and press Register
  <li>Head Back Over to the Login Section and Use the Information you registed with and Login
</ol>
As Oer the status Now Creating a Free Server Or Purchasing a server is Only possible Through Our Discord

!!! Bug

    If any of the data Provided is Invalid Please Report this to a Staff Member
    In our Discord Server.

    